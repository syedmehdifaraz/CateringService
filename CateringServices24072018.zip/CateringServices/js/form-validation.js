// Wait for the DOM to be ready
$(function() {
$.validator.addMethod("validateLoginID", function(value, element) {
	if(document.getElementById('loginid').value.length){
		if(isloginidvalidated){
			return true;
		}
	}else{return true;}
    }, "Please validate");  // Initialize form validation on the Distributor registration form.
  $('form[name="addSalesUserfrm"]').validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      firstname: {
        required: true
       // maxlength: 25
      },
     /* lastname: {
        required: true,
        maxlength: 25
      },*/
	  role:{
        required: true,
		digits: true,
        maxlength: 25
      },
	  loginid:{
        required: true,
        maxlength: 20
      },
	  Email: {
        /*required: true,
        email: true,
        maxlength: 50,*/
		validateLoginID: true
      }
    },
    // Specify validation error messages
    messages: {
      firstname: {
        required: ''
    //    maxlength: 'First Name is limited to 25 characters'
      },
  /*    lastname: {
        required: 'Please enter last name',
        maxlength: 'Only 25 characters allowed'
      }, */
	  loginid: {
        required: 'Please enter login id',		
        maxlength: 'Only 20 characters allowed'
      },
	  role: {
        required: 'Please enter role',
		digits: 'Please enter numbers only',
        maxlength: 'Only 25 characters allowed'
      },
	  Email: {
        /*required: '',
        email: 'Please enter the valid email',
        maxlength: 'Only 50 characters allowed',*/
		validateLoginID: 'Click find to populate first name, last name and email address' 
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      addAdminSales();
    }
  });

$.validator.addMethod("LoginIDRegex1", function(value, element) {//$.isNumeric(value.trim().slice(0, 1))) ||
	if(!((value.trim().length == 7 && $.isNumeric(value.trim().substring(2,7)) && (value.trim().substring(0,2).toLowerCase() == 'be' || value.trim().substring(0,2).toLowerCase() == 'bp')) || $.isNumeric(value.trim().slice(0, 1)) || !(/^\S+$/.test(value.trim())) )) return true;
    }, "Login ID cannot start with BE/BP");

  $('form[name="addNewAspireUserfrm"]').validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      nloginid: {
        required: true,
		minlength: 4,
		maxlength: 20,
		LoginIDRegex1: true
      },
      nfname: {
        required: true
      },
      nlname: {
        required: true
      },
      ncompany: {
        required: true
      },
	  nemail: {
        required: true,
        email: true,
        maxlength: 50
      }

    },
    // Specify validation error messages
    messages: {
      nloginid: {
        required: 'Please enter login id',
		minlength: 'Please enter at least 4 characters.',
        maxlength: 'Login ID is limited to 20 characters',
		LoginIDRegex1: 'Please enter valid login id'
      },
     nfname: {
        required: 'Please enter first name'
      },
     nlname: {
        required: 'Please enter last name'
      },
     ncompany: {
        required: 'Please enter company'
      },
	  nemail: {
        required: 'Please enter email',
        email: 'Please enter the valid email',
        maxlength: 'Only 50 characters allowed'
      }

    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      addNewAspireUser();
    }
  });
 $('form[name="editSalesUserfrm"]').validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      editfirstname: {
        required: true,
        maxlength: 25
      },
      editlastname: {
        required: true,
        maxlength: 25
      },
	  editrole:{
        required: true,
		digits: true,
        maxlength: 25
      },
	  editloginid:{
        required: true,
        maxlength: 25
      },
	  editemail: {
        required: true,
        email: true,
        maxlength: 50
      }
    },
    // Specify validation error messages
    messages: {
      editfirstname: {
        required: 'Please enter first name',
        maxlength: 'First Name is limited to 25 characters'
      },
      editlastname: {
        required: 'Please enter last name',
        maxlength: 'Only 25 characters allowed'
      },
	  editloginid: {
        required: 'Please enter login id',		
        maxlength: 'Only 25 characters allowed'
      },
	 editrole: {
        required: 'Please enter role',
		digits: 'Please enter numbers only',
        maxlength: 'Only 25 characters allowed'
      },
	  editemail: {
        required: 'Please enter email',
        email: 'Please enter the valid email',
        maxlength: 'Only 50 characters allowed'
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      editAdminSales();
    }
  });
 
 $('form[name="addSkillfrm"]').validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      skillname: {
        required: true,
        maxlength: 50
      }
    },
    // Specify validation error messages
    messages: {
      skillname: {
        required: 'Please enter skill name',
        maxlength: 'Skill Name is limited to 50 characters'
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {	
      addSkillSubmit();
    }
  });
  $('form[name="editSkillfrm"]').validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      editskillname: {
        required: true,
        maxlength: 50
      }
    },
    // Specify validation error messages
    messages: {
      editskillname: {
        required: 'Please enter skill name',
        maxlength: 'Skill Name is limited to 50 characters'
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      editSkillSubmit();
    }
  });



$('form[name="addRolefrm"]').validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      RoleName: {
        required: true,
        maxlength: 100
      },
	  WebSortOrder:{
		  digits: true,
		  min:1
	  }
    
    },
    // Specify validation error messages
    messages: {
      RoleName: {
        required: 'Please enter role name',
        maxlength: 'Role name is limited to 100 characters'
      },
	  WebSortOrder: {
        digits:'Please enter numbers only',
		min:'Enter positive number only'
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {	
      addRoleSubmit();
    }
  });
$('form[name="addJobfrm"]').validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      JobName: {
        required: true,
        maxlength: 100
      },
	  WebSortOrder:{
		  digits: true,
		  min : 1
		}
    },
    // Specify validation error messages
    messages: {
      JobName: {
        required: 'Please enter Accountability',
        maxlength: 'Accountability is limited to 100 characters'
      },
	  WebSortOrder: {
        digits:'Please enter numbers only',
		min:'Enter positive number only'
      }
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {	
      addJobSubmit();
    }
  });







// override jquery validate plugin defaults
$.validator.setDefaults({
  highlight: function(element) {
    $(element).closest('.form-group').addClass('has-error');
  },
  unhighlight: function(element) {
    $(element).closest('.form-group').removeClass('has-error');
  },
  errorElement: 'span',
  errorClass: 'error',
  errorPlacement: function(error, element) {
    if(element.parent('.input-group').length) {
      error.insertAfter(element.parent());
    } else {
      error.insertAfter(element);
    }
  }
});
});
