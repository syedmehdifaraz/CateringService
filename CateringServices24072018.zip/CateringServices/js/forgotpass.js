function getQuestion(){

document.getElementById('error').style.display ="none";
var usernameemail = 	document.getElementById("usernameemail").value;

if(usernameemail.toUpperCase() == 'SHRADDHEY' ){
document.getElementById("showAlertUserRegistered").style.display = "block";
document.getElementById("getUserName").style.display = "none";
window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove();
			  	document.getElementById("verifyQuestion").style.display = "block";

					document.getElementById("usernameemail").disabled = true;
          document.getElementById("showAlertUserRegistered").style.display = "none";
    });
}, 700);

}
else if (usernameemail == "") {
document.getElementById('error').style.display ="block";
return ;
	}
else {
document.getElementById("showAlertNotRegistered").style.display = "block";
window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove();
			location.reload();
    });
}, 700);
	}

}


function verifyAnswer(){
  //document.getElementById("verifyOTP").style.display = "block";

  document.getElementById('errorAnswer').style.display ="none";
  var answer1 = 	document.getElementById("answer1").value;
  var answer2 = 	document.getElementById("answer2").value;
  if(answer1.toUpperCase() == 'SHRADDHEY' & answer2.toUpperCase()== 'PAGARIA' ){
      window.open("setnewpassword.html","_self")
  }
  else if (answer1 == "" || answer2 == "") {
  document.getElementById('errorAnswer').style.display ="block";
  document.getElementById('errorAnswer').innerHTML ="Please Enter Answers";
  return ;
  	}
  else {
  document.getElementById('errorAnswer').style.display ="block";
  document.getElementById('errorAnswer').innerHTML ="Please Enter Correct Answer";
  	}

  }
